from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
import numpy as np
from datetime import datetime
from ahp_utils import calculate_weights, check_consistency

app = Flask(__name__)
client = MongoClient("mongodb://localhost:27017/")
db = client["ahp_db"]
history_collection = db["ahp_history"]

criteria_names = ["Ổn định giá", "Tăng trưởng dài hạn", "Tính thanh khoản", "Khả năng chống lạm phát", "Rủi ro đầu tư"]
alternatives = ["Vàng", "Ngoại tệ", "Cổ phiếu", "Trái phiếu"]

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        matrix = np.ones((5, 5))
        for i in range(5):
            for j in range(i + 1, 5):
                val = float(request.form.get(f"cell_{i}_{j}", 1))
                matrix[i][j] = val
                matrix[j][i] = 1 / val

        weights = calculate_weights(matrix)
        cr = check_consistency(matrix, weights)

        np.random.seed(42)
        scores = np.random.rand(4, 5)
        final_scores = np.dot(scores, weights)
        ranked = list(zip(alternatives, final_scores))
        ranked.sort(key=lambda x: x[1], reverse=True)

        result = {
            "timestamp": datetime.now(),
            "weights": weights.tolist(),
            "CR": round(cr, 4),
            "ranked": [{"option": r[0], "score": round(r[1], 4)} for r in ranked]
        }

        history_collection.insert_one(result)
        return render_template("result.html", result=result)

    return render_template("index.html", criteria=criteria_names)

@app.route("/history")
def history():
    records = list(history_collection.find().sort("timestamp", -1))
    return render_template("history.html", records=records)

if __name__ == "__main__":
    app.run(debug=True)
