import numpy as np

def calculate_weights(matrix):
    col_sum = matrix.sum(axis=0)
    norm_matrix = matrix / col_sum
    weights = norm_matrix.mean(axis=1)
    return weights

def check_consistency(matrix, weights):
    lam_max = np.sum(np.dot(matrix, weights) / weights) / len(weights)
    CI = (lam_max - len(weights)) / (len(weights) - 1)
    RI = {1: 0, 2: 0, 3: 0.58, 4: 0.90, 5: 1.12}.get(len(weights), 1.12)
    CR = CI / RI if RI else 0
    return CR
